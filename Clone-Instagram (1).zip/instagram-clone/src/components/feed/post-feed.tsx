"use client";

import { useState } from "react";
import Image from "next/image";
import Link from "next/link";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";
import { MoreHorizontal, Heart, MessageCircle, Send, Bookmark } from "lucide-react";

// Mock data for posts
const POSTS = [
  {
    id: "1",
    user: {
      name: "johndoe",
      username: "johndoe",
      avatar: "https://github.com/shadcn.png",
      verified: true,
    },
    image: "https://images.unsplash.com/photo-1682686581221-c126206d12f0",
    caption: "Amazing sunset at the beach today! #sunset #beach #summer",
    likes: 1024,
    comments: 64,
    postedAt: "2 hours ago",
  },
  {
    id: "2",
    user: {
      name: "janesmith",
      username: "janesmith",
      avatar: "https://github.com/shadcn.png",
      verified: false,
    },
    image: "https://images.unsplash.com/photo-1574629810360-7efbbe195018",
    caption: "Morning coffee and coding session ☕💻 #coding #developer #coffee",
    likes: 512,
    comments: 32,
    postedAt: "5 hours ago",
  },
  {
    id: "3",
    user: {
      name: "mike_ross",
      username: "mike_ross",
      avatar: "https://github.com/shadcn.png",
      verified: true,
    },
    image: "https://images.unsplash.com/photo-1516116216624-53e697fedbea",
    caption: "Just finished my workout 💪 Feeling great! #fitness #workout #health",
    likes: 768,
    comments: 48,
    postedAt: "1 day ago",
  },
];

export default function PostFeed() {
  return (
    <div className="flex flex-col gap-4">
      {POSTS.map((post) => (
        <Post key={post.id} post={post} />
      ))}
    </div>
  );
}

function Post({ post }: { post: typeof POSTS[0] }) {
  const [isLiked, setIsLiked] = useState(false);
  const [isSaved, setIsSaved] = useState(false);

  return (
    <Card className="overflow-hidden border border-gray-300">
      <CardHeader className="flex flex-row items-center justify-between p-4">
        <div className="flex items-center gap-3">
          <Avatar className="h-8 w-8">
            <AvatarImage src={post.user.avatar} alt={post.user.name} />
            <AvatarFallback>{post.user.name[0].toUpperCase()}</AvatarFallback>
          </Avatar>
          <div className="flex items-center">
            <Link href={`/profile/${post.user.username}`} className="font-semibold">
              {post.user.username}
            </Link>
            {post.user.verified && (
              <span className="ml-1 rounded-full bg-blue-500 p-0.5 text-white">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 24"
                  fill="currentColor"
                  className="h-3 w-3"
                >
                  <path
                    fillRule="evenodd"
                    d="M19.916 4.626a.75.75 0 01.208 1.04l-9 13.5a.75.75 0 01-1.154.114l-6-6a.75.75 0 011.06-1.06l5.353 5.353 8.493-12.739a.75.75 0 011.04-.208z"
                    clipRule="evenodd"
                  />
                </svg>
              </span>
            )}
          </div>
        </div>
        <Button variant="ghost" size="icon" className="h-8 w-8">
          <MoreHorizontal className="h-5 w-5" />
        </Button>
      </CardHeader>
      <div className="relative aspect-square">
        <Image src={post.image} alt={post.caption} fill className="object-cover" />
      </div>
      <CardContent className="p-4">
        <div className="flex items-center justify-between pb-2">
          <div className="flex items-center gap-4">
            <Button
              variant="ghost"
              size="icon"
              className="h-8 w-8 p-0"
              onClick={() => setIsLiked(!isLiked)}
            >
              <Heart
                className={`h-6 w-6 ${isLiked ? "fill-red-500 text-red-500" : ""}`}
              />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
              <MessageCircle className="h-6 w-6" />
            </Button>
            <Button variant="ghost" size="icon" className="h-8 w-8 p-0">
              <Send className="h-6 w-6" />
            </Button>
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="h-8 w-8 p-0"
            onClick={() => setIsSaved(!isSaved)}
          >
            <Bookmark className={`h-6 w-6 ${isSaved ? "fill-black" : ""}`} />
          </Button>
        </div>
        <div className="pb-1 font-semibold">{post.likes.toLocaleString()} likes</div>
        <div>
          <span className="font-semibold">{post.user.username}</span>{" "}
          <span>{post.caption}</span>
        </div>
        <Link href={`/p/${post.id}`} className="pt-1 text-sm text-gray-500">
          View all {post.comments} comments
        </Link>
        <div className="pt-1 text-xs text-gray-500">{post.postedAt}</div>
      </CardContent>
      <CardFooter className="border-t border-gray-200 p-0">
        <input
          type="text"
          placeholder="Add a comment..."
          className="flex-1 border-0 bg-transparent p-4 text-sm focus:outline-none"
        />
        <Button variant="ghost" className="mr-2 px-4 text-sm font-semibold text-blue-500">
          Post
        </Button>
      </CardFooter>
    </Card>
  );
}
