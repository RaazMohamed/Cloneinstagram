import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea, ScrollBar } from "@/components/ui/scroll-area";

const USERS = [
  {
    name: "johndoe",
    image: "https://github.com/shadcn.png",
    hasNewStory: true,
  },
  {
    name: "janesmith",
    image: "https://github.com/shadcn.png",
    hasNewStory: true,
  },
  {
    name: "mike_ross",
    image: "https://github.com/shadcn.png",
    hasNewStory: true,
  },
  {
    name: "rachelzane",
    image: "https://github.com/shadcn.png",
    hasNewStory: true,
  },
  {
    name: "harveyspecter",
    image: "https://github.com/shadcn.png",
    hasNewStory: false,
  },
  {
    name: "donnapaulsen",
    image: "https://github.com/shadcn.png",
    hasNewStory: false,
  },
  {
    name: "jessicapearson",
    image: "https://github.com/shadcn.png",
    hasNewStory: true,
  },
  {
    name: "louis_litt",
    image: "https://github.com/shadcn.png",
    hasNewStory: false,
  },
  {
    name: "katrina_bennett",
    image: "https://github.com/shadcn.png",
    hasNewStory: true,
  },
  {
    name: "alexwilliams",
    image: "https://github.com/shadcn.png",
    hasNewStory: false,
  },
];

export default function Stories() {
  return (
    <div className="rounded-lg border border-gray-300 bg-white p-4">
      <ScrollArea className="w-full whitespace-nowrap">
        <div className="flex w-max space-x-4 p-1">
          {USERS.map((user) => (
            <StoryAvatar
              key={user.name}
              name={user.name}
              image={user.image}
              hasNewStory={user.hasNewStory}
            />
          ))}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  );
}

function StoryAvatar({
  name,
  image,
  hasNewStory,
}: {
  name: string;
  image: string;
  hasNewStory: boolean;
}) {
  return (
    <div className="flex flex-col items-center gap-1">
      <div className={`p-[2px] rounded-full ${hasNewStory ? "instagram-gradient" : "bg-gray-200"}`}>
        <div className="rounded-full p-[2px] bg-white">
          <Avatar className="h-14 w-14 cursor-pointer">
            <AvatarImage src={image} alt={name} />
            <AvatarFallback>{name[0].toUpperCase()}</AvatarFallback>
          </Avatar>
        </div>
      </div>
      <span className="text-xs">{name.length > 10 ? `${name.slice(0, 10)}...` : name}</span>
    </div>
  );
}
