import Link from "next/link";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";

// Mock data for suggestions
const SUGGESTIONS = [
  {
    id: "1",
    username: "tech_lover",
    name: "Tech Enthusiast",
    avatar: "https://github.com/shadcn.png",
    reason: "New to Instagram",
  },
  {
    id: "2",
    username: "travel_buddy",
    name: "Travel Buddy",
    avatar: "https://github.com/shadcn.png",
    reason: "Followed by user1, user2",
  },
  {
    id: "3",
    username: "foodie_explorer",
    name: "Foodie Explorer",
    avatar: "https://github.com/shadcn.png",
    reason: "Suggested for you",
  },
  {
    id: "4",
    username: "fitness_guru",
    name: "Fitness Guru",
    avatar: "https://github.com/shadcn.png",
    reason: "Followed by user3",
  },
  {
    id: "5",
    username: "photo_artist",
    name: "Photography Artist",
    avatar: "https://github.com/shadcn.png",
    reason: "Popular account",
  },
];

export default function Suggestions() {
  return (
    <div className="flex flex-col gap-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Avatar className="h-14 w-14">
            <AvatarImage src="https://github.com/shadcn.png" alt="Your account" />
            <AvatarFallback>YA</AvatarFallback>
          </Avatar>
          <div>
            <div className="font-semibold">current_user</div>
            <div className="text-sm text-gray-500">Current User</div>
          </div>
        </div>
        <Button variant="link" className="text-xs font-semibold text-blue-500">
          Switch
        </Button>
      </div>

      <div className="flex items-center justify-between pt-2">
        <span className="text-sm font-semibold text-gray-500">Suggestions For You</span>
        <Button variant="link" className="text-xs font-semibold">
          See All
        </Button>
      </div>

      <div className="flex flex-col gap-3">
        {SUGGESTIONS.map((suggestion) => (
          <div key={suggestion.id} className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Avatar className="h-8 w-8">
                <AvatarImage src={suggestion.avatar} alt={suggestion.name} />
                <AvatarFallback>{suggestion.name[0].toUpperCase()}</AvatarFallback>
              </Avatar>
              <div>
                <Link href={`/profile/${suggestion.username}`} className="text-sm font-semibold">
                  {suggestion.username}
                </Link>
                <div className="text-xs text-gray-500">{suggestion.reason}</div>
              </div>
            </div>
            <Button variant="link" className="text-xs font-semibold text-blue-500">
              Follow
            </Button>
          </div>
        ))}
      </div>

      <div className="pt-4 text-xs text-gray-500">
        <div className="flex flex-wrap gap-x-1">
          <Link href="#" className="hover:underline">About</Link> ·
          <Link href="#" className="hover:underline">Help</Link> ·
          <Link href="#" className="hover:underline">Press</Link> ·
          <Link href="#" className="hover:underline">API</Link> ·
          <Link href="#" className="hover:underline">Jobs</Link> ·
          <Link href="#" className="hover:underline">Privacy</Link> ·
          <Link href="#" className="hover:underline">Terms</Link> ·
          <Link href="#" className="hover:underline">Locations</Link> ·
          <Link href="#" className="hover:underline">Language</Link>
        </div>
        <div className="pt-4">© 2025 INSTAGRAM FROM META</div>
      </div>
    </div>
  );
}
