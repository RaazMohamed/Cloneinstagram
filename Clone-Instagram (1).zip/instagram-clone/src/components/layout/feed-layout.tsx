import type { ReactNode } from "react";
import Link from "next/link";
import Image from "next/image";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import {
  Home, Search, Compass, Camera, Heart,
  MessageCircle, PlusSquare, Menu
} from "lucide-react";

export default function FeedLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      {/* Sidebar (Desktop) */}
      <aside className="sticky top-0 hidden h-screen w-[244px] flex-col justify-between border-r border-gray-300 bg-white p-4 md:flex">
        <div className="flex flex-col gap-8">
          <div className="py-4 pl-3">
            <h1 className="text-2xl font-semibold italic">Instagram</h1>
          </div>
          <nav className="flex flex-col gap-1">
            <NavItem href="/dashboard" icon={<Home className="h-6 w-6" />} label="Home" active />
            <NavItem href="/explore" icon={<Search className="h-6 w-6" />} label="Search" />
            <NavItem href="/explore" icon={<Compass className="h-6 w-6" />} label="Explore" />
            <NavItem href="/reels" icon={<Camera className="h-6 w-6" />} label="Reels" />
            <NavItem href="/messages" icon={<MessageCircle className="h-6 w-6" />} label="Messages" />
            <NavItem href="/notifications" icon={<Heart className="h-6 w-6" />} label="Notifications" />
            <NavItem href="/create" icon={<PlusSquare className="h-6 w-6" />} label="Create" />
            <NavItem
              href="/profile"
              icon={
                <Avatar className="h-6 w-6">
                  <AvatarImage src="https://github.com/shadcn.png" alt="User" />
                  <AvatarFallback>U</AvatarFallback>
                </Avatar>
              }
              label="Profile"
            />
          </nav>
        </div>
        <Button variant="ghost" className="mt-auto flex w-full justify-start gap-4 px-3 font-normal">
          <Menu className="h-6 w-6" />
          <span>More</span>
        </Button>
      </aside>

      {/* Mobile Nav */}
      <div className="sticky top-0 border-b border-gray-300 bg-white p-3 md:hidden">
        <div className="flex items-center justify-between">
          <h1 className="text-xl font-semibold italic">Instagram</h1>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="h-9 w-9">
              <Heart className="h-6 w-6" />
            </Button>
            <Button variant="ghost" size="icon" className="h-9 w-9">
              <MessageCircle className="h-6 w-6" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="flex-1 bg-gray-50 pb-16 md:pb-0">
        <div className="mx-auto max-w-[935px]">{children}</div>
      </main>

      {/* Bottom Nav (Mobile) */}
      <nav className="fixed bottom-0 left-0 right-0 flex justify-around border-t border-gray-300 bg-white p-3 md:hidden">
        <Button variant="ghost" size="icon" className="h-9 w-9">
          <Home className="h-6 w-6" />
        </Button>
        <Button variant="ghost" size="icon" className="h-9 w-9">
          <Search className="h-6 w-6" />
        </Button>
        <Button variant="ghost" size="icon" className="h-9 w-9">
          <PlusSquare className="h-6 w-6" />
        </Button>
        <Button variant="ghost" size="icon" className="h-9 w-9">
          <Camera className="h-6 w-6" />
        </Button>
        <Button variant="ghost" size="icon" className="h-9 w-9">
          <Avatar className="h-6 w-6">
            <AvatarImage src="https://github.com/shadcn.png" alt="User" />
            <AvatarFallback>U</AvatarFallback>
          </Avatar>
        </Button>
      </nav>
    </div>
  );
}

function NavItem({
  href,
  icon,
  label,
  active = false
}: {
  href: string;
  icon: ReactNode;
  label: string;
  active?: boolean;
}) {
  return (
    <Link href={href}>
      <Button
        variant={active ? "secondary" : "ghost"}
        className={`flex w-full justify-start gap-4 px-3 font-normal ${active ? 'font-medium' : ''}`}
      >
        {icon}
        <span>{label}</span>
      </Button>
    </Link>
  );
}
