import FeedLayout from "@/components/layout/feed-layout";
import PostFeed from "@/components/feed/post-feed";
import Stories from "@/components/feed/stories";
import Suggestions from "@/components/feed/suggestions";

export default function DashboardPage() {
  return (
    <FeedLayout>
      <div className="grid grid-cols-1 gap-8 px-2 py-4 md:grid-cols-3 lg:px-0">
        <div className="col-span-2 flex flex-col gap-6">
          <Stories />
          <PostFeed />
        </div>
        <div className="sticky top-20 hidden h-fit md:block">
          <Suggestions />
        </div>
      </div>
    </FeedLayout>
  );
}
