import Link from "next/link";
import Image from "next/image";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card";

export default function SignupPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center px-4 py-12 sm:px-6 lg:px-8">
      <div className="w-full max-w-md">
        <Card className="w-full border border-gray-300 bg-white px-4 py-6">
          <CardHeader className="pb-2 pt-0 text-center">
            <div className="mb-4 mt-4 flex items-center justify-center">
              <h1 className="text-[36px] font-semibold italic text-black">Instagram</h1>
            </div>
            <h2 className="text-center text-base font-semibold text-gray-500">
              Sign up to see photos and videos from your friends.
            </h2>

            <Button className="mt-4 w-full bg-[#0095F6] text-white hover:bg-[#1877F2]">
              <svg className="mr-2 h-5 w-5" fill="currentColor" viewBox="0 0 24 24">
                <path d="M12 2.04c-5.5 0-10 4.49-10 10.02 0 5 3.66 9.15 8.44 9.9v-7H7.9v-2.9h2.54V9.85c0-2.51 1.49-3.89 3.78-3.89 1.09 0 2.23.19 2.23.19v2.47h-1.26c-1.24 0-1.63.77-1.63 1.56v1.88h2.78l-.45 2.9h-2.33v7a10 10 0 008.44-9.9c0-5.53-4.5-10.02-10-10.02z" />
              </svg>
              Log in with Facebook
            </Button>

            <div className="relative my-4 flex items-center">
              <div className="flex-grow border-t border-gray-300" />
              <span className="mx-4 flex-shrink text-sm font-semibold text-gray-500">OR</span>
              <div className="flex-grow border-t border-gray-300" />
            </div>
          </CardHeader>

          <CardContent className="space-y-4 pb-2">
            <form className="space-y-4">
              <Input
                type="text"
                placeholder="Mobile number or email"
                className="h-9 bg-gray-50 text-sm"
              />
              <Input
                type="text"
                placeholder="Full Name"
                className="h-9 bg-gray-50 text-sm"
              />
              <Input
                type="text"
                placeholder="Username"
                className="h-9 bg-gray-50 text-sm"
              />
              <Input
                type="password"
                placeholder="Password"
                className="h-9 bg-gray-50 text-sm"
              />

              <p className="text-center text-xs text-gray-500">
                People who use our service may have uploaded your contact information to Instagram.{" "}
                <Link href="#" className="text-[#00376B]">
                  Learn More
                </Link>
              </p>

              <p className="text-center text-xs text-gray-500">
                By signing up, you agree to our{" "}
                <Link href="#" className="text-[#00376B]">
                  Terms
                </Link>
                ,{" "}
                <Link href="#" className="text-[#00376B]">
                  Privacy Policy
                </Link>{" "}
                and{" "}
                <Link href="#" className="text-[#00376B]">
                  Cookies Policy
                </Link>
                .
              </p>

              <Button type="submit" className="w-full bg-[#0095F6] text-white hover:bg-[#1877F2]">
                Sign up
              </Button>
            </form>
          </CardContent>
        </Card>

        <Card className="mt-4 w-full border border-gray-300 bg-white p-6 text-center">
          <CardContent className="p-0">
            <p className="text-sm">
              Have an account?{" "}
              <Link href="/" className="font-semibold text-[#0095F6]">
                Log in
              </Link>
            </p>
          </CardContent>
        </Card>

        <div className="mt-4 text-center">
          <p className="text-sm">Get the app.</p>
          <div className="mt-4 flex items-center justify-center gap-4">
            <Link href="https://apps.apple.com/app/instagram/id389801252" target="_blank">
              <Image
                src="https://ext.same-assets.com/1191372574/1294075298.png"
                alt="Download on the App Store"
                width={136}
                height={40}
                className="h-10 w-auto"
              />
            </Link>
            <Link href="https://play.google.com/store/apps/details?id=com.instagram.android" target="_blank">
              <Image
                src="https://ext.same-assets.com/1191372574/3590352490.png"
                alt="Get it on Google Play"
                width={136}
                height={40}
                className="h-10 w-auto"
              />
            </Link>
          </div>
        </div>
      </div>

      {/* Footer */}
      <footer className="mt-16 w-full max-w-md text-center text-xs text-gray-500">
        <div className="mb-4 flex flex-wrap justify-center gap-4">
          <Link href="#" className="hover:underline">Meta</Link>
          <Link href="#" className="hover:underline">About</Link>
          <Link href="#" className="hover:underline">Blog</Link>
          <Link href="#" className="hover:underline">Jobs</Link>
          <Link href="#" className="hover:underline">Help</Link>
          <Link href="#" className="hover:underline">API</Link>
          <Link href="#" className="hover:underline">Privacy</Link>
          <Link href="#" className="hover:underline">Terms</Link>
          <Link href="#" className="hover:underline">Top Accounts</Link>
          <Link href="#" className="hover:underline">Locations</Link>
          <Link href="#" className="hover:underline">Instagram Lite</Link>
          <Link href="#" className="hover:underline">Threads</Link>
        </div>
        <div className="flex items-center justify-center gap-4">
          <select className="bg-transparent text-xs">
            <option value="en">English</option>
            <option value="es">Español</option>
            <option value="fr">Français</option>
          </select>
          <span>© 2025 Instagram from Meta</span>
        </div>
      </footer>
    </div>
  );
}
